#include <QLabel>
#include <QLineEdit>
#include <QTableView>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QString>
#include <QButtonGroup>
#include <QRadioButton>
#include <QSpinBox>
#include <QGroupBox>
#include <QPushButton>
#include <QMessageBox>

#include "calculator.h"

#define MIN_BUT_WIDTH 30
#define MIN_BUT_HEIGHT 30
#define MAX_BUT_WIDTH 50
#define MAX_BUT_HEIGHT 50
#define NORMAL_FONT_SIZE 8
#define BIG_FONT_SIZE 18

Calculator::Calculator(QWidget *parent)
    : QWidget(parent)
{

    // vytvoreni hlavniho Grid Layoutu - rozmisteni komponent v okne
    layout = new QGridLayout;

    // panel pro display
    panel = new QVBoxLayout;
    display = new QLineEdit("0",this);
    display->setReadOnly(true);
    display->setAlignment( Qt::AlignRight);
    panel->addWidget(display);
    layout->addLayout(panel, 0, 0, 1, 4);

    //panel pro radiobuttony
    hbox = new QHBoxLayout();
    radioButtons = new QGroupBox(this);
    norRBut = new QRadioButton(QString("Normal"),radioButtons);
    bigRBut = new QRadioButton(QString("Big"),radioButtons);
    hbox->addWidget(norRBut);
    hbox->addWidget(bigRBut);
    radioButtons->setLayout(hbox);
    radioButtons->setMaximumHeight(40);
    layout->addWidget(radioButtons, 1, 0, 1, 4);
    //connect(norRBut,SIGNAL(clicked()),this,SLOT(clickNorButton()));
    //connect(bigRBut,SIGNAL(clicked()),this,SLOT(clickBigButton()));
    
    //jednotliva tlacitka
    but1 = new QPushButton("1",this);
    but2 = new QPushButton("2",this);
    but3 = new QPushButton("3",this);
    but4 = new QPushButton("4",this);
    but5 = new QPushButton("5",this);
    but6 = new QPushButton("6",this);
    but7 = new QPushButton("7",this);
    but8 = new QPushButton("8",this);
    but9 = new QPushButton("9",this);
    but0 = new QPushButton("0",this);


    but1->setMinimumSize(MIN_BUT_WIDTH, MIN_BUT_HEIGHT);
    but2->setMinimumSize(MIN_BUT_WIDTH, MIN_BUT_HEIGHT);
    but3->setMinimumSize(MIN_BUT_WIDTH, MIN_BUT_HEIGHT);
    but4->setMinimumSize(MIN_BUT_WIDTH, MIN_BUT_HEIGHT);
    but5->setMinimumSize(MIN_BUT_WIDTH, MIN_BUT_HEIGHT);
    but6->setMinimumSize(MIN_BUT_WIDTH, MIN_BUT_HEIGHT);
    but7->setMinimumSize(MIN_BUT_WIDTH, MIN_BUT_HEIGHT);
    but8->setMinimumSize(MIN_BUT_WIDTH, MIN_BUT_HEIGHT);
    but9->setMinimumSize(MIN_BUT_WIDTH, MIN_BUT_HEIGHT);
    but0->setMinimumSize(MIN_BUT_WIDTH, MIN_BUT_HEIGHT);

    but1->setFont(QFont("SanSerif", NORMAL_FONT_SIZE, QFont::Normal));


    addBut = new QPushButton("+",this);
    addBut->setMinimumSize(MIN_BUT_WIDTH, MIN_BUT_HEIGHT);

    connect(but1,SIGNAL(clicked()),this,SLOT(clickButton1()));
    connect(but2,SIGNAL(clicked()),this,SLOT(clickButton2()));
    connect(but3,SIGNAL(clicked()),this,SLOT(clickButton3()));
    connect(but4,SIGNAL(clicked()),this,SLOT(clickButton4()));

    layout->addWidget(but1, 4, 0);
    layout->addWidget(but2, 4, 1);
    layout->addWidget(but3, 4, 2);
    layout->addWidget(but4, 3, 0);
    layout->addWidget(but5, 3, 1);
    layout->addWidget(but6, 3, 2);
    layout->addWidget(but7, 2, 0);
    layout->addWidget(but8, 2, 1);
    layout->addWidget(but9, 2, 2);
    layout->addWidget(but0, 5, 0, 1, 2);

    layout->addWidget(addBut, 2, 3);

    setLayout( layout );
}

Calculator::~Calculator()
{

}

void Calculator::insNumeral(char c){
                QString txt = display->text();
                txt.append(c);
                display->setText(txt);
}

void Calculator::clickButton1() {
        insNumeral('1');
}
void Calculator::clickButton2() {
        insNumeral('2');
}
void Calculator::clickButton3() {
        insNumeral('3');
}
void Calculator::clickButton4() {
        insNumeral('4');
}
void Calculator::clickNorButton(){

    display->setText("normal");

}
void Calculator::clickBigButton(){

    display->setText("big");

}
