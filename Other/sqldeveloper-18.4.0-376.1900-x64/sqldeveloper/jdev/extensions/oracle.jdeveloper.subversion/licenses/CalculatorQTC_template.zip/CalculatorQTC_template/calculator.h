#ifndef CONVERTER_H
#define CONVERTER_H

#include <QWidget>

class QLineEdit;
class QSpinBox;
class QRadioButton;
class QPushButton;
class QGridLayout;
class QVBoxLayout;
class QHBoxLayout;
class QGroupBox;



class Calculator : public QWidget
{
    Q_OBJECT

    QGridLayout *layout;
    QVBoxLayout *panel;
    QHBoxLayout *hbox;
    QLineEdit  *display;
    QGroupBox *radioButtons;
    QRadioButton *norRBut, *bigRBut;
    QPushButton *but1, *but2, *but3, *but4, *but5, *but6, *but7, *but8, *but9, *but0;
    QPushButton *addBut;

    bool newNumExpected;
    bool fltPoint;
    double opA;
    double opB;
    char idOp;

public:
    Calculator(QWidget *parent = 0);
    ~Calculator();

private:
    void insNumeral(char c);

private slots:
    void clickButton1();
    void clickButton2();
    void clickButton3();
    void clickButton4();
    void clickNorButton();
    void clickBigButton();

};

#endif // CONVERTER_H
